<?php
    setcookie("uname","");
    setcookie("vip","");
    setcookie("id","");
    echo "<script>window.location.href='index.php' </script>";
?>
